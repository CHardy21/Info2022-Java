package com.example.Informatorio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InformatorioApplicationTests {

	@Test
	void contextLoads() {
	}

}

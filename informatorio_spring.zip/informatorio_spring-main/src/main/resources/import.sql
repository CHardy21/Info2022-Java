INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');
INSERT INTO `users` (nombre_persona, apellido_persona, fecha_nacimiento, dni_persona, email_persona) VALUES ('Rosten', 'Ross', '2017-08-01', 369258147 ,'rosten_ross@gmail.com');


INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('Maria', 'Pepita', 12212312,'2022-09-28');
INSERT INTO `patients` (name, lastname,  dni, birthdate) VALUES ('Josefa', 'Macana', 123212312,'2022-10-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('Mario', 'Bofil', 12332312,'2022-07-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('Metalica', 'Naruto', 12342312,'2022-10-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('Lucifer', 'Goku', 1242312,'2022-10-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('Mario', 'Bros', 12312212,'2022-10-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('Luigi', 'Bros', 1234312,'2022-07-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('LG', 'Lgante', 1231112,'2022-10-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('asdasda', 'sdfgsd', 12322312,'2022-10-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('sdf', 'sf', 1234312,'2022-06-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('sdf', 'sfds', 12312412,'2022-10-28');
INSERT INTO `patients` (name, lastname, dni, birthdate) VALUES ('hgfsd', 'sdfsd', 1252312,'2022-10-28');





package com.turnosRegistro.shift.record.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter @AllArgsConstructor
public class UserPartDto {
    private Long id;
    private String email;
}

package com.turnosRegistro.shift.record;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShiftRecordApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShiftRecordApplication.class, args);
	}

}

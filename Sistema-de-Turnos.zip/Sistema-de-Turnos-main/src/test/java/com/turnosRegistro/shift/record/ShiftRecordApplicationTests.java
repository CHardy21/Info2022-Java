package com.turnosRegistro.shift.record;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShiftRecordApplicationTests {

	@Test
	void contextLoads() {
	}

}
